CREATE DATABASE employee_db;
